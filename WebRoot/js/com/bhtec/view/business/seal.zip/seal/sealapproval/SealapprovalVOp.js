/**
 * 编码操作
 * @author lianglp
 * @version 1.0
 */
Ext.namespace('com.bhtec.view.business.seal.sealapproval');
com.bhtec.view.business.seal.sealapproval.SealapprovalVOp = function(config){
	var moduleVOp = this;   //父类调用
	var moduleGridId = 'sealApplyApprovalGridId';//form表单id

	/**
	 * 点击列表查看，弹出查看页面
	 */
	var viewForm = function(){
		var modDelRecord = modifyDelSelRecord(moduleGridId);//请选择一条件记录
		if(modDelRecord != ''){
			var configFind = {
					url:'codeAction!findSysplCodeByCodeId.action',
					params:{modViewRecId:modDelRecord.codeId},
					callBack:function(returnData){
						var configForm = {
							title:'系统编码查看',
							moduleData:returnData.model,
							allButtonHidden:true
						}
						funForm(configForm);
					}
			}
			ajaxRequest(configFind);
		}
	}


	//印章信息修改
	var sealInfoApproval = function(view){
		var syncUrl = 'sealAction!findApprovalPersonInfo.action';
		var data = syncAjaxReqDecode(syncUrl,'');

		var modDelRecord = modifyDelSelRecord(moduleGridId);//请选择一条件记录

		if(modDelRecord != ''){
			var status = '待审核'
			if(config.status == '3'){
				status = '重报待审核';
			}
			//批单基本信息
			var approvalInfo = moduleVOp.fieldSet({
				id:'approvalInfoId',
				title:'批单基本信息',				//窗口title
				layout:'form',
				autoHeight:true,
				columnFields:[
					moduleVOp.panel({
					height:30,
					items:[
						moduleVOp.label({
							text : (config.approvalNum+' : '),
							style:"padding:5px 0px"
						}),moduleVOp.label({
							text : (modDelRecord.approvalNum ),
							style:"padding:5px 0px"
						})
					]
				}),moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.status+' : ')
							}),moduleVOp.label({
								text : status
							})
						]
					})]	//表单第一列
			});

			//申刻单位信息
			var approvalUnitInfo = moduleVOp.fieldSet({
				id:'approvalUnitId',
				title:'申刻单位信息',				//窗口title
				layout:'form',
				autoHeight:true,
				columnFields:[
					moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.unitName+' : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : (modDelRecord.unitName ),
								style:"padding:5px 0px"
							})
						]
					}),moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.manager+' : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : modDelRecord.manager,
								style:"padding:5px 0px"
							})
						]
					}),moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.phone+'     : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : modDelRecord.phone,
								style:"padding:5px 0px"
							})
						]
					})]	//表单第一列
			});

			//申刻人信息
			var approvalPersonInfo = moduleVOp.fieldSet({
				id:'approvalPersonId',
				title:'申刻人信息',				//窗口title
				layout:'form',
				autoHeight:true,
				columnFields:[
					moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.applyPerson+' : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : (modDelRecord.applyPerson ),
								style:"padding:5px 0px"
							})
						]
					}),moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.applyPersonPhone+' : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : modDelRecord.applyPersonPhone,
								style:"padding:5px 0px"
							})
						]
					})]	//表单第一列
			});

			//申刻人信息
			var delegationInfo = moduleVOp.fieldSet({
				id:'delegationInfoId',
				title:'批单委托单位信息',				//窗口title
				layout:'form',
				autoHeight:true,
				columnFields:[
					moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.creatorUnit+' : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : (modDelRecord.creatorUnit ),
								style:"padding:5px 0px"
							})
						]
					}),moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.createDate+' : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : modDelRecord.createDate,
								style:"padding:5px 0px"
							})
						]
					}),moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.creator+' : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : modDelRecord.creator,
								style:"padding:5px 0px"
							})
						]
					}),moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.creatorPhone+' : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : modDelRecord.creatorPhone,
								style:"padding:5px 0px"
							})
						]
					}),moduleVOp.panel({
						height:30,
						items:[
							moduleVOp.label({
								text : (config.applyMemo+' : '),
								style:"padding:5px 0px"
							}),moduleVOp.label({
								text : (modDelRecord.applyMemo=='')?'无':modDelRecord.applyMemo,
								style:"padding:5px 0px"
							})
						]
					})]	//表单第一列
			});

			//印章列表
			var gridPanel = moduleVOp.gridPanel({
				id:'sealGridPanelId',
				autoHeight:true,
				autoWidth:true,
				colums	: [{
					dataIndex : 'sealApplyDetailId',
					hidden: true
				},{
					header : config.sealType,
					dataIndex : 'sealType',
					width : 100,
					sortable: true
				},{
					header : config.sealName,
					dataIndex : 'sealName',
					width : 100,
					sortable: true
				},{
					header : config.sealSpecification,
					dataIndex : 'sealSpecification',
					width : 100,
					sortable: true
				},{
					header : config.bingkanType,
					dataIndex : 'bingkanType',
					width : 100,
					sortable: true
				},{
					header : config.bingkanInfo,
					dataIndex : 'bingkanInfo',
					width : 100,
					sortable: true
				},{
					header : config.zhongkanType,
					dataIndex : 'zhongkanType',
					width : 100,
					sortable: true
				},{
					header : config.sealMaterial,
					dataIndex : 'sealMaterial',
					width : 100,
					sortable: true
				},{
					header : config.oilType,
					dataIndex : 'oilType',
					width : 100,
					sortable: true
				},{
					dataIndex : 'word1',
					width : 100,
					hidden: true
				},{
					dataIndex : 'word2',
					width : 100,
					hidden: true
				},{
					dataIndex : 'word3',
					width : 100,
					hidden: true
				},{
					dataIndex : 'word4',
					width : 100,
					hidden: true
				},{
					dataIndex : 'word5',
					width : 100,
					hidden: true
				},{
					dataIndex : 'word6',
					width : 100,
					hidden: true
				}],
				gridStore:new Ext.data.JsonStore({
					url:'sealAction!findApprovalSealApplyDetail.action',
					fields : ['sealApplyDetailId','sealType','sealName','sealSpecification','bingkanType','bingkanInfo',
						'zhongkanType','sealMaterial','oilType','word1','word2','word3','word4','word5','word6'],
					baseParams :{
						sealApplyId:modDelRecord.sealApplyId
					},
					root:'sealApplyDetialEntities',
					autoLoad : true
				}),
				bbar:{}
			});
			//印章列表
			var fieldSetGrid = {
				xtype	  : 'fieldset',
				id:'sealModifyGridId',
				title	  : '印章列表',
				layout 	  : 'form',
				autoHeight:true,
				autoWidth:true,
				// bodyStyle : 'margin:10px;',
				items 	  : [gridPanel]
			};


			var formPanel = {
				xtype: 'form',
				id: 'sealModifyFormId',
				border: false,
				autoHeight: true,
				autoWidth: true,
				trackResetOnLoad: true,
				labelWidth: 80,
				hidden:view=='view'?true:false,
				items: [{
					xtype:'htmleditor',
					id:'historyApprovalCommentId',
					name:'historyApprovalCommentId',
					value:modDelRecord.refuse||'',
					fieldLabel : '历史审批意见',
					width: 650,
					height: 130
				},{
					xtype:'htmleditor',
					id:'approvalCommentId',
					name:'approvalCommentId',
					value:data.currentUserInfo||'',
					fieldLabel : '审批意见',
					width: 650,
					height: 130
				},moduleVOp.radio({
					id : "isAgree",
					name : "isAgree",
					fieldLabel : '快速输入',
					width:250,
					items:[
						{boxLabel: '审批通过', name: 'approvalRadio', inputValue: 1,
							listeners:{
								'check':function(checkbox,checked){
									if(checked){
										// var approvalComment = getExtCmpValueById('approvalCommentId');
										getExtCmpById('approvalCommentId').setValue((data.currentUserInfo||'')+'<br>审批通过');
									}
								}
							}},
						{boxLabel: '审批不通过', name: 'approvalRadio', inputValue: 0,
							listeners:{
								'check':function(checkbox,checked){
									if(checked){
										// var approvalComment = getExtCmpValueById('approvalCommentId');
										getExtCmpById('approvalCommentId').setValue((data.currentUserInfo||'')+'<br>审批不通过');
									}
								}
							}}
					]
				}),{
					id:'sealPanelBtnId',
					xtype	  : 'panel',
					layout 	  : 'column',
					border    : false,
					style:'margin-top:20px;',
					bodyStyle:'margin-left:150px;',
					autoHeight:true,
					items:[{
						border : false,
						columnWidth : 0.2,
						items : [{
							xtype : 'button',
							iconCls : 'table_edit',
							text : '查看审核材料',
							handler : function(){
								getExtCmpById('sealModifyId').close();
							}
						}
						]
					},{
						border : false,
						layout : "form",
						columnWidth : 0.2,
						items : [{
							xtype : 'button',
							id : "sealAddBtnId",
							iconCls : 'table_save',
							text : '审批通过',
							handler : function(){
								askMesg({
									msg: '您确认审批通过吗?',
									fn: function (confirm) {
										if (confirm == 'ok') {
											var configFind = {
												url:'sealAction!modifySealApplyApproval.action',
												params:{
													sealApplyId:modDelRecord.sealApplyId,
													status:'1',
													refuse:getExtCmpValueById('approvalCommentId')
												},
												callBack:function(returnData){
													var configCb = {
														msg : '审批通过 成功!',
														fn : function(confirm) {
															if ('ok' == confirm) {
																getExtCmpById('sealModifyId').close();
																refreshGridList('sealApplyApprovalGridId');
															}
														}
													}
													showSucMesg(configCb);
												}
											}
											ajaxRequest(configFind);
										}
									}
								});

							}
						}]
					}, {
						border : false,
						layout : "form",
						columnWidth : 0.2,
						items : [{
							xtype : 'button',
							iconCls : 'table_close',
							text : '审批不通过',
							handler : function(){
								askMesg({
									msg: '您确认审批通过吗?',
									fn: function (confirm) {
										if (confirm == 'ok') {
											var configFind = {
												url: 'sealAction!modifySealApplyApproval.action',
												params: {
													sealApplyId: modDelRecord.sealApplyId,
													status: '0',
													refuse: getExtCmpValueById('approvalCommentId')
												},
												callBack: function (returnData) {
													var configCb = {
														msg: '审批不通过 成功!',
														fn: function (confirm) {
															if ('ok' == confirm) {
																getExtCmpById('sealModifyId').close();
																refreshGridList('sealApplyApprovalGridId');
															}
														}
													}
													showSucMesg(configCb);
												}
											}
											ajaxRequest(configFind);
										}
									}
								});
							}
						}
						]
					},{
						border : false,
						layout : "form",
						columnWidth : 0.2,
						items : [{
							xtype : 'button',
							iconCls : 'table_close',
							text : '关闭',
							handler : function(){
								getExtCmpById('sealModifyId').close();
							}
						}
						]
					}]
				}]
			}

			moduleVOp.window({
				id:'sealModifyId',
				title:'印章信息',
				autoScroll:true,
				items:[approvalInfo,approvalUnitInfo,
					approvalPersonInfo,delegationInfo,
					fieldSetGrid,formPanel]
			});
		}
	}

	return {
			viewForm:viewForm,
			sealInfoApproval:sealInfoApproval
	}
}

Ext.extend(com.bhtec.view.business.seal.sealapproval.SealapprovalVOp, com.bhtec.view.util.CommonWidgets, {});